# EOD Dispatcher — Packaging Guide

This must be built **on Windows**, with Outlook installed — `pywin32` and the
Outlook COM automation this app relies on don't exist on macOS/Linux.

## Build

1. Copy this whole folder (`EOD_Dispatcher.py`, `requirements.txt`,
   `EOD_Dispatcher.spec`, `build.bat`) onto the Windows machine.
2. Double-click `build.bat`.
3. When it finishes, your app is at:
   `dist\EOD_Dispatcher\EOD_Dispatcher.exe`

## Run it

Double-click `EOD_Dispatcher.exe` inside the `dist\EOD_Dispatcher` folder.
It should open in well under a second — no self-extraction delay.

## Distributing it to other people

Zip the **entire** `dist\EOD_Dispatcher` folder and send that — not just the
`.exe` by itself. The exe needs the DLLs and the pandas/openpyxl/pywin32
files sitting next to it in that folder to run.

If you want a single `setup.exe` that installs it to Program Files and adds
a Start Menu shortcut instead of "unzip and run," wrap this same
`dist\EOD_Dispatcher` folder with a free tool like
[Inno Setup](https://jrsoftware.org/isinfo.php) — a few lines of script
pointing at this folder is enough. Ask if you want that `.iss` script
written out too.

## Why onedir instead of onefile

`--onefile` bundles everything into a single `.exe`, which looks tidier,
but PyInstaller has to unpack that `.exe` into a temp folder **every time
it launches** — that's the multi-second "why is this so slow to open"
delay people usually mean when an app "wraps" like this. `--onedir` (what
`EOD_Dispatcher.spec` uses) ships the exe next to its dependencies
unpacked already, so there's nothing to extract at launch.

## If Outlook automation errors on the packaged exe but not from source

This is almost always one of:
- Outlook itself isn't installed / not signed in on that machine.
- A prior antivirus/Windows Defender flag on the exe — PyInstaller exes
  trip heuristic scanners sometimes; whitelist the `dist` folder.
- Missing `win32timezone` — already included as a hidden import in the
  spec file, but if you hit it anyway, add it to `hiddenimports` again
  and rebuild with `--clean`.
