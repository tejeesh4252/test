# -*- mode: python ; coding: utf-8 -*-
#
# Builds in --onedir mode on purpose. --onefile is more convenient to hand
# someone (one .exe), but it self-extracts to a temp folder on EVERY launch,
# which is almost always the real cause of "the app takes forever to open."
# --onedir launches the exe directly off disk — near-instant every time.
# Distribute the whole dist/EOD_Dispatcher folder (zip it, or wrap it with
# an installer like Inno Setup if you want a single setup.exe for users).

block_cipher = None

a = Analysis(
    ['EOD_Dispatcher.py'],
    pathex=[],
    binaries=[],
    datas=[],
    # win32timezone isn't always auto-detected by PyInstaller's pywin32
    # hooks and its absence shows up as a runtime error the first time
    # Outlook automation touches a date/time value.
    hiddenimports=['win32timezone'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # Trims dead weight pandas can drag in that this app never uses —
    # smaller build, faster to load.
    excludes=[
        'matplotlib', 'scipy', 'IPython', 'notebook',
        'PyQt5', 'PySide2', 'pytest',
    ],
    noarchive=False,
    cipher=block_cipher,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,          # keep deps external -> onedir, not onefile
    name='EOD_Dispatcher',
    debug=False,
    strip=False,
    upx=False,                      # UPX compresses the exe; decompressing
                                     # it again on every launch costs time —
                                     # not worth it for a few MB saved.
    console=False,                  # GUI app: no console window behind it
    icon=None,                      # set to 'path/to/icon.ico' if you have one
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='EOD_Dispatcher',
)
