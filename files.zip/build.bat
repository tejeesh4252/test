@echo off
REM Run this on the Windows machine that has Outlook installed.
REM Creates dist\EOD_Dispatcher\EOD_Dispatcher.exe

python -m venv venv
call venv\Scripts\activate.bat

pip install --upgrade pip
pip install -r requirements.txt

pyinstaller EOD_Dispatcher.spec --clean

echo.
echo ============================================
echo Build complete.
echo Run:  dist\EOD_Dispatcher\EOD_Dispatcher.exe
echo Distribute the WHOLE dist\EOD_Dispatcher folder,
echo not just the .exe on its own.
echo ============================================
pause
